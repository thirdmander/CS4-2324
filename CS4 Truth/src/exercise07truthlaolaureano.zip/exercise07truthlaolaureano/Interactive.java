package exercise07truthlaolaureano;

public interface Interactive {
    void interact();
}
