package CS4_Exercise_2;

public class Roommate{
        String fullName;
        int messagesCount;
        boolean hasJowa;
        
        public Roommate(String name, int numOfMsgs, boolean jowaStatus){
        fullName = name;
        messagesCount = numOfMsgs;
        hasJowa = jowaStatus;
        }
}
