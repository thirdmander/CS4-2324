package CS4_Exercise_2;

public class Song {
    String songTitle;
    String songArtist;
    int songLength; // in seconds

    public Song(String title, String artist, int length) {
        songTitle = title;
        songArtist = artist;
        songLength = length;
    }
}
