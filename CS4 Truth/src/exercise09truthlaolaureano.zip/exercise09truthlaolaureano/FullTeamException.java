package exercise09truthlaolaureano;

public class FullTeamException extends Exception {
    public FullTeamException(String msg){
        super(msg);
    }
}
