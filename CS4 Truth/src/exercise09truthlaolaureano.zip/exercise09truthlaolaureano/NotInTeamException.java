package exercise09truthlaolaureano;

public class NotInTeamException extends Exception {
    public NotInTeamException(String msg){
        super(msg);
    }
}