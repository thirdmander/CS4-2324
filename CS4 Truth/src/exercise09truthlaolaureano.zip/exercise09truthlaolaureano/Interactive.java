package exercise09truthlaolaureano;

public interface Interactive {
    void interact();
}
