package exercise09truthlaolaureano;

public class AlreadyCapturedException extends Exception {
    public AlreadyCapturedException(String msg){
        super(msg);
    }
}
