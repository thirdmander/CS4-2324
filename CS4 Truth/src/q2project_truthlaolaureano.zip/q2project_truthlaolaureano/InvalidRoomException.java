package q2project_truthlaolaureano;

public class InvalidRoomException extends Exception {
    public InvalidRoomException(String s){
        super(s);
    }
}
