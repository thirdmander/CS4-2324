package q2project_truthlaolaureano;

public class WrongKeyException  extends Exception{
    public WrongKeyException(String s){
        super(s);
    }
}
