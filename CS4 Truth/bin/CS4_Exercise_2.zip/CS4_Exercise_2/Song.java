package CS4_Exercise_2;

public class Song {
    String songTitle;
    String songArtist;
    int songLength; // in seconds

    public Song(String songTitle, String songArtist, int songLength) {
        this.songTitle = songTitle;
        this.songArtist = songArtist;
        this.songLength = songLength;
    }
}
