package CS4_Exercise_2;

public class Roommate{
        String fullName;
        int messagesCount;
        boolean hasJowa;
        
        public Roommate(String fullName, int messagesCount, boolean hasJowa){
        this.fullName = fullName;
        this.messagesCount = messagesCount;
        this.hasJowa = hasJowa;
        }
}
