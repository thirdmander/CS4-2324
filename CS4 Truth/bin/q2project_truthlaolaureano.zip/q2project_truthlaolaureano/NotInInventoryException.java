package q2project_truthlaolaureano;

public class NotInInventoryException extends Exception {
    public NotInInventoryException(String s){
        super(s);
    }
}
