package q2project_truthlaolaureano;

public class InventoryFullException extends Exception {
    public InventoryFullException(String s){
        super(s);
    }
}
